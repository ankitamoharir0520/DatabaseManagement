create view min_tweet1 as select min(TweetFollowers) from twitter_user_data;

create view director_award1 as select d.category, m.genre, min(m.budget) FROM director d INNER JOIN movie m ON m.director = d.director where m.budget<35000000 and m.budget>0;

create view movie_old as select min(a.established),a.company,count(b.movie) from company a, movie b where a.company=b.company;

create view movie_rating1 as select distinct rating from movie where movie = (select min(Film) from actor_final where Award='Writing (Screenplay Based on Material from Another Medium)');

create view user_post as select distinct UserTweets from twitter_user_data where ScreenName = 'aigis_txt';

select * from min_tweet1;
select * from director_award1;
select * from movie_old;
select * from movie_rating1;
select * from user_post;
