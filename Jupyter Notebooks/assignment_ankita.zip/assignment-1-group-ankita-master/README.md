DMDD ASSIGNMENT

We will be using the data to model, gather, clean and database to analyze Social Media for a particular domain.
We have considered movies domain with consumer, producers, companies as actors, directors and production companies as the main entities.
We will be collecting relatable live data from social media platfroms and create various use cases to satisy the given conditions.
